var lado = parseInt (prompt ("Digite o valor do lado do quadrado:"))
var area = lado * lado
alert("a area do quadrado  é: " + area )