var nota1 = parseFloat(prompt("digite a primeira nota"))
var nota2 = parseFloat(prompt("digite a segunda nota"))
var nota3 = parseFloat(prompt("digite a terceira nota"))

var media = (nota1 + nota2 + nota3) / 3

alert(" A Média é de " + media)