var raio = parseInt (prompt ("Digite o raio:"))
var area = 3.14 * raio ** 2

alert("a area do circulo  é: " + area )