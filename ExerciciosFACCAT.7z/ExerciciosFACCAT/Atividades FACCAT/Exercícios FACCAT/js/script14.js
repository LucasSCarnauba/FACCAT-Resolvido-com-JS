var base = parseInt (prompt ("Digite a base do triangulo:"))
var altura = parseInt (prompt ("Digite a altura do triangulo:"))
var area = (base * altura) / 2
alert("a area do triangulo  é: " + area )