var numero1 = parseInt (prompt ("Digite o numero:"))
var antecessor = (numero1 -1)

alert("o antecessor de "+ numero1 +" é: " + antecessor )