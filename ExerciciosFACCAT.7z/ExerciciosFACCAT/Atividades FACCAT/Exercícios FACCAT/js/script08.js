var numero1 = parseFloat (prompt ("Digite o primeiro numero:"))
var numero2 = parseFloat (prompt ("Digite o segundo numero:"))
var resultado = (numero1 / numero2)

alert("a divisão total é de: " + resultado )