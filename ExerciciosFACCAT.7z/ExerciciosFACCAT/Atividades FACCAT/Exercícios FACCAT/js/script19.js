var c = parseFloat(prompt("Digite o valor do grau "))
var f = (c * 9) / 5 + 32

alert("O valor em fahrenheit é de " + f)