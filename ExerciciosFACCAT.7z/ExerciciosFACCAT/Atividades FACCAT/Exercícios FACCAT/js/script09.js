var numero1 = parseInt (prompt ("Digite o numero:"))
var sucessor = (numero1 +1)

alert("o sucessor de "+ numero1 +" é: " + sucessor )