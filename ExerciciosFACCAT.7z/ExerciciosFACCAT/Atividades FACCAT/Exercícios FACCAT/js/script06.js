var numero1 = parseInt (prompt ("Digite o primeiro numero:"))
var numero2 = parseInt (prompt ("Digite o segundo numero:"))
var resultado = (numero1 - numero2)

alert("a subtração total é de: " + resultado )