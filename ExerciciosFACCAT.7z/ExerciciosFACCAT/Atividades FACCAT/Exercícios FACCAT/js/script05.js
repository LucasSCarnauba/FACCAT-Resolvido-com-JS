var numero1 = parseInt (prompt ("Digite o primeiro numero:"))
var numero2 = parseInt (prompt ("Digite o segundo numero:"))
var soma = (numero1 + numero2)

alert("a soma total é de: " + soma )