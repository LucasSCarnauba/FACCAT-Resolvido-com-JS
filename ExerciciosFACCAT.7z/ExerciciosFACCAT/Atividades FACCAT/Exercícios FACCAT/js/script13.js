var lado = parseInt (prompt ("Digite altura do retangulo:"))
var lado2 = parseInt (prompt ("Digite o comprimento do retangulo:"))
var area = lado * lado2
alert("a area do retangulo  é: " + area )